package com.azizah.msocial;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.firebase.DataCollectionDefaultChange;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.nio.channels.DatagramChannel;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatAct extends AppCompatActivity {

    Toolbar toolbar;
    RecyclerView recyclerView;
    CircleImageView imgprof;
    TextView namacht, statuson;
    EditText pesanet;
    ImageButton sendbtn;
    FirebaseAuth firebaseAuth;
    String hisUid;
    String myUid, hisImage;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReferenceuser;

    ValueEventListener seenlist;
    DatabaseReference databaseReferenceseen;

    List<Datachat> chatlist;
    Adapterchat adapterchat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        toolbar = findViewById(R.id.toolbr);
        setSupportActionBar(toolbar);
        toolbar.setTitle("");
        recyclerView = findViewById(R.id.cht_recycler);
        imgprof = findViewById(R.id.profimg);
        namacht = findViewById(R.id.namacht);
        statuson = findViewById(R.id.statuson);
        pesanet = findViewById(R.id.pesanet);
        sendbtn = findViewById(R.id.sendbtn);

        firebaseAuth = FirebaseAuth.getInstance();

        Intent chatt = getIntent();
        hisUid = chatt.getStringExtra("hisUid");

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setStackFromEnd(true);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReferenceuser = firebaseDatabase.getReference("Users");

        Query queryu = databaseReferenceuser.orderByChild("uid").equalTo(hisUid);
        queryu.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot ds: dataSnapshot.getChildren()){

                    String name = ""+ds.child("name").getValue();
                    hisImage = ""+ds.child("image").getValue();
                    String onstatus = ""+ ds.child("onlineST").getValue();
                    String ketikan = ""+ ds.child("mengetik").getValue();

                    if(ketikan.equals(myUid)){
                        statuson.setText("Sedang Mengetik...");
                    }
                    else{
                        if(onstatus.equals("online")){
                            statuson.setText(onstatus);
                        }

                        else{
                            statuson.setText("");

                        }
                    }



                    namacht.setText(name);
                    try{
                        Picasso.get().load(hisImage).placeholder(R.drawable.ic_usr_name).into(imgprof);
                    }
                    catch (Exception e){


                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        sendbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pesan = pesanet.getText().toString().trim();
                if(TextUtils.isEmpty(pesan)){

                    Toast.makeText(ChatAct.this, "Tidak dapat mengirim pesan kosong", Toast.LENGTH_SHORT).show();

                }
                else{
                    kirimpesan(pesan);
                }
            }
        });

        bacapesan();

        dilihat();

        pesanet.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if(charSequence.toString().trim().length() ==0){
                    cekketik("tidakada");
                }
                else{
                    cekketik(hisUid);
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void dilihat() {
        databaseReferenceseen = FirebaseDatabase.getInstance().getReference("Chats");
        seenlist = databaseReferenceseen.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot ds: dataSnapshot.getChildren()){
                    Datachat chat = ds.getValue(Datachat.class);
                    if(chat.getReceiver().equals(myUid) && chat.getSender().equals(hisUid)){
                        HashMap<String, Object> hasSeenHashMap = new HashMap<>();
                        hasSeenHashMap.put("seen", true);
                        ds.getRef().updateChildren(hasSeenHashMap);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void bacapesan() {
        chatlist = new ArrayList<>();
        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("Chats");
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                chatlist.clear();
                for(DataSnapshot ds: dataSnapshot.getChildren()){
                    Datachat chat = ds.getValue(Datachat.class);
                    if(chat.getReceiver().equals(myUid) && chat.getSender().equals(hisUid) ||
                    chat.getReceiver().equals(hisUid) && chat.getSender().equals(myUid)){
                        chatlist.add(chat);
                    }

                    adapterchat = new Adapterchat(ChatAct.this, chatlist, hisImage);
                    adapterchat.notifyDataSetChanged();
                    recyclerView.setAdapter(adapterchat);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void kirimpesan(String pesan) {
        DatabaseReference databaseReference =FirebaseDatabase.getInstance().getReference();

        String timestamp = String.valueOf(System.currentTimeMillis());

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("sender", myUid);
        hashMap.put("receiver", hisUid);
        hashMap.put("message", pesan);
        hashMap.put("seen", false);
        hashMap.put("timestamp", timestamp);
        databaseReference.child("Chats").push().setValue(hashMap);

        pesanet.setText("");
    }

    private void setSupportActionBar(Toolbar toolbar) {

    }

    private void checkuser(){

        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null){

            myUid = user.getUid();

        }

        else{
            startActivity(new Intent(this, MainActivity.class));
           finish();
        }
    }



    private void  checkOnline(String status){
        DatabaseReference dbrf = FirebaseDatabase.getInstance().getReference("Users").child(myUid);
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("onlineST", status);

        dbrf.updateChildren(hashMap);
    }

    private void  cekketik(String mengetik){
        DatabaseReference dbrf = FirebaseDatabase.getInstance().getReference("Users").child(myUid);
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("mengetik", mengetik);

        dbrf.updateChildren(hashMap);
    }

    @Override
    protected void onStart() {
        checkuser();
        checkOnline("online");
        super.onStart();
    }

    @Override
    protected void onPause() {

        super.onPause();
        checkOnline("");
        cekketik("tidakada");
        databaseReferenceseen.removeEventListener(seenlist);

    }

    @Override
    protected void onResume() {
        checkOnline("online");
        super.onResume();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.logout, menu);
        menu.findItem(R.id.searchin).setVisible(false);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public  boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if(id==R.id.logout){
            firebaseAuth.signOut();
            checkuser();
        }
        return super.onOptionsItemSelected(item);
    }
}
