package com.azizah.msocial;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageInfo;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class Adapterchat extends RecyclerView.Adapter<Adapterchat.MyHolder> {

    private static final int MSG_TYPE_LEFT = 0;
    private static final int MSG_TYPE_RIGHT =1;
    Context context;
    List<Datachat> chatlist;
    FirebaseUser firebaseUser;
    String imgurl;

    public Adapterchat(Context context, List<Datachat> chatlist, String imgurl) {
        this.context = context;
        this.chatlist = chatlist;
        this.imgurl = imgurl;
    }



    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        if (viewType == MSG_TYPE_RIGHT){
            View view = LayoutInflater.from(context).inflate(R.layout.sebelahkiri, parent, false);
            return new MyHolder(view);
        }
        else{
            View view = LayoutInflater.from(context).inflate(R.layout.sebelahkanan, parent, false);
            return new MyHolder(view);
        }


    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int position) {

        String message = chatlist.get(position).getMessage();



        holder.pesancht.setText(message);

        try{
            Picasso.get().load(imgurl).into(holder.profile);
        }
        catch (Exception e){

        }

        holder.layarpesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Hapus");
                builder.setMessage("Apakah Anda yakin ingin menghapus pesan ini?");
                builder.setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        hapuspesan1(position);
                    }
                });
                builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                builder.create().show();
            }
        });

        if( position == chatlist.size()-1){
            if(chatlist.get(position).isSeen()){
                holder.seen.setText("Dibaca");
            }
            else{
                holder.seen.setText("Terkirim");
            }
        }

        else {
            holder.seen.setVisibility(View.GONE);
        }

    }

    private void hapuspesan1(int i) {

        final String myUID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        String msgtime = chatlist.get(i).getTimestamp();
        DatabaseReference drb = FirebaseDatabase.getInstance().getReference("Chats");
        Query querr = drb.orderByChild("timestamp").equalTo(msgtime);
        querr.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot dataSnapshot1: dataSnapshot.getChildren()){
                    if(dataSnapshot1.child("sender").getValue().equals(myUID)){

                        dataSnapshot1.getRef().removeValue();


                    }
                    else{

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    @Override
    public int getItemCount() {
        return chatlist.size();
    }

    @Override
    public int getItemViewType(int position) {
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        if(chatlist.get(position).getSender().equals(firebaseUser.getUid())){
            return MSG_TYPE_LEFT;
        }
        else{
            return MSG_TYPE_RIGHT;
        }
    }

    class MyHolder extends RecyclerView.ViewHolder{

        TextView pesancht, seen;
        CircleImageView profile;
        LinearLayout layarpesan;

        public MyHolder(@NonNull View item){
            super(item);

            layarpesan = item.findViewById(R.id.layarpesan);
            profile = item.findViewById(R.id.profiletv);
            pesancht = item.findViewById(R.id.pesantv);
            seen   = item.findViewById(R.id.seen);

        }
    }

}
