package com.azizah.msocial;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class AdapterData extends RecyclerView.Adapter<AdapterData.MyHolder> {


    public AdapterData(Context context, List<DataUser> dataUsers) {
        this.context = context;
        this.dataUsers = dataUsers;
    }

    Context context;
    List<DataUser> dataUsers;

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.list_user, parent, false);


        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        final String hishuid = dataUsers.get(position).getUid();
        String uimg = dataUsers.get(position).getImage();
        final String uname = dataUsers.get(position).getName();
        String ubio = dataUsers.get(position).getBio();

        holder.namatvv.setText(uname);
        holder.biotvv.setText(ubio);
        try{

            Picasso.get().load(uimg).placeholder(R.drawable.ic_usr_name).into(holder.imgv);

        }
        catch (Exception e){

        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent cht = new Intent(context, ChatAct.class);
                cht.putExtra("hisUid", hishuid);
                context.startActivity(cht);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataUsers.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        CircleImageView imgv;
        TextView namatvv, biotvv;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            imgv = itemView.findViewById(R.id.imgv);
            namatvv = itemView.findViewById(R.id.namatvv);
            biotvv = itemView.findViewById(R.id.biotvv);
        }
    }
}
